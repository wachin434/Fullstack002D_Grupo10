package com.TimeCraftIncorporate.Timecraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimecraftApplicationTests {

	@Test
	void contextLoads() {
	}

}
